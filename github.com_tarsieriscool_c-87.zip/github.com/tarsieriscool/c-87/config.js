// Import the functions you need from the SDKs you need

export const firebaseConfig = {
  apiKey: "AIzaSyBphA_jHSphNdKp6WVGmE1kyxSdP7yR5pE",
  authDomain: "story-telling-app-3c312.firebaseapp.com",
  projectId: "story-telling-app-3c312",
  storageBucket: "story-telling-app-3c312.appspot.com",
  messagingSenderId: "843788254365",
  appId: "1:843788254365:web:1cd3d79c1b080be43a6874"
};

